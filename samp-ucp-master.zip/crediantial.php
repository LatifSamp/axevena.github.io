<?php
define('EMAIL','YOUR EMAIL','Fransisco Roleplay');
define('PASS','YOUR PASSWORD');